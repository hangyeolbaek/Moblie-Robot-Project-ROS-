#!/usr/bin/env python
import rospy
from std_msgs.msg import String
from std_msgs.msg import UInt16
from sensor_msgs.msg import LaserScan

def pub():
    global send_value
    pub = rospy.Publisher('driving', String, queue_size=1000)
    rospy.init_node('pub_test')
    rate = rospy.Rate(10)
    while not rospy.is_shutdown():
        
        pub.publish(send_value)
        rate.sleep()

if __name__ == '__main__':
    send_value = "front"
    pub()
