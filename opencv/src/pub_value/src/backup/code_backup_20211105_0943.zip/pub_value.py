#!/usr/bin/env python
import rospy
import time
import math
from std_msgs.msg import String
from std_msgs.msg import UInt16
from sensor_msgs.msg import LaserScan

def callback(msg):
  #(+)degree is left. Opposition to rplidar_A1.png
  #rospy.loginfo("deg : %0.3f" %msg.ranges[0])
    global deg0, deg40, deg45, deg78, deg90, deg137, deg223, deg270, deg282, deg315, deg320, send_value

    if msg.ranges[0] <= 8.000:
        deg0=msg.ranges[0]
        #print("^_________________________________^")
    elif msg.ranges[0] >= 8.000 and msg.ranges[1] <= 8.000:
        deg0=msg.ranges[1]
        #print("^_________________________________^")
    elif msg.ranges[0] >= 8.000 and msg.ranges[1] >= 8.000 and msg.ranges[359] <= 8.000:
        deg0=msg.ranges[359]
        #print("^_________________________________^")
    else:
        #print("deg 0 lost")
        print("dump")

    if msg.ranges[40] <= 8.000:
        deg40=msg.ranges[40]
        #print("^_________________________________^")
    elif msg.ranges[40] >= 8.000 and msg.ranges[39] <= 8.000:
        deg40=msg.ranges[39]
        #print("^_________________________________^")
    elif msg.ranges[40] >= 8.000 and msg.ranges[39] >= 8.000 and msg.ranges[41] <= 8.000:
        deg40=msg.ranges[41]
        #print("^_________________________________^")
    else:
        #print("deg 40 lost")
        print("dump")

    if msg.ranges[45] <= 8.000:
        deg45=msg.ranges[45]
        #print("^_________________________________^")
    elif msg.ranges[45] >= 8.000 and msg.ranges[46] <= 8.000:
        deg45=msg.ranges[46]
        #print("^_________________________________^")
    elif msg.ranges[45] >= 8.000 and msg.ranges[46] >= 8.000 and msg.ranges[44] <= 8.000:
        deg45=msg.ranges[44]
        #print("^_________________________________^")
    else:
        #print("deg 45 lost")
        print("dump")

    if msg.ranges[78] <= 8.000:
        deg78=msg.ranges[78]
        #print("^_________________________________^")
    elif msg.ranges[78] >= 8.000 and msg.ranges[77] <= 8.000:
        deg78=msg.ranges[77]
        #print("^_________________________________^")
    elif msg.ranges[78] >= 8.000 and msg.ranges[77] >= 8.000 and msg.ranges[79] <= 8.000:
        deg78=msg.ranges[79]
        #print("^_________________________________^")
    else:
        #print("deg 78 lost")
        print("dump")

    if msg.ranges[90] <= 8.000:
        deg90=msg.ranges[90]
        #print("^_________________________________^")
    elif msg.ranges[90] >= 8.000 and msg.ranges[89] <= 8.000:
        deg90=msg.ranges[89]
        #print("^_________________________________^")
    elif msg.ranges[90] >= 8.000 and msg.ranges[89] >= 8.000 and msg.ranges[91] <= 8.000:
        deg90=msg.ranges[91]
        #print("^_________________________________^")
    else:
        #print("deg 90 lost")
        print("dump")

    if msg.ranges[137] <= 8.000:
        deg137=msg.ranges[137]
        #print("^_________________________________^")
    elif msg.ranges[137] >= 8.000 and msg.ranges[136] <= 8.000:
        deg137=msg.ranges[136]
        #print("^_________________________________^")
    elif msg.ranges[137] >= 8.000 and msg.ranges[136] >= 8.000 and msg.ranges[138] <= 8.000:
        deg137=msg.ranges[138]
        #print("^_________________________________^")
    else:
        #print("deg 137 lost")
        print("dump")

    if msg.ranges[223] <= 8.000:
        deg223=msg.ranges[223]
        #print("^_________________________________^")
    elif msg.ranges[223] >= 8.000 and msg.ranges[224] <= 8.000:
        deg223=msg.ranges[224]
        #print("^_________________________________^")
    elif msg.ranges[223] >= 8.000 and msg.ranges[224] >= 8.000 and msg.ranges[222] <= 8.000:
        deg223=msg.ranges[222]
        #print("^_________________________________^")
    else:
        #print("deg 223 lost")
        print("dump")

    if msg.ranges[270] <= 8.000:
        deg270=msg.ranges[270]
        #print("^_________________________________^")
    elif msg.ranges[270] >= 8.000 and msg.ranges[271] <= 8.000:
        deg270=msg.ranges[271]
        #print("^_________________________________^")
    elif msg.ranges[270] >= 8.000 and msg.ranges[271] >= 8.000 and msg.ranges[269] <= 8.000:
        deg270=msg.ranges[269]
        #print("^_________________________________^")
    else:
        #print("deg 270 lost")
        print("dump")

    if msg.ranges[282] <= 8.000:
        deg282=msg.ranges[282]
        #print("^_________________________________^")
    elif msg.ranges[282] >= 8.000 and msg.ranges[283] <= 8.000:
        deg282=msg.ranges[283]
        #print("^_________________________________^")
    elif msg.ranges[282] >= 8.000 and msg.ranges[283] >= 8.000 and msg.ranges[281] <= 8.000:
        deg282=msg.ranges[281]
        #print("^_________________________________^")
    else:
        #print("deg 282 lost")
        print("dump")
        #print("^_________________________________^")

    if msg.ranges[315] <= 8.000:
        deg315=msg.ranges[315]
        #print("^_________________________________^")
    elif msg.ranges[315] >= 8.000 and msg.ranges[316] <= 8.000:
        deg315=msg.ranges[316]
        #print("^_________________________________^")
    elif msg.ranges[315] >= 8.000 and msg.ranges[316] >= 8.000 and msg.ranges[314] <= 8.000:
        deg315=msg.ranges[314]
        #print("^_________________________________^")
    else:
        #print("deg 315 lost")
        print("dump")
        #print("^_________________________________^")

    if msg.ranges[320] <= 8.000:
        deg320=msg.ranges[320]
        #print("^_________________________________^")
    elif msg.ranges[320] >= 8.000 and msg.ranges[321] <= 8.000:
        deg320=msg.ranges[321]
        #print("^_________________________________^")
    elif msg.ranges[320] >= 8.000 and msg.ranges[321] >= 8.000 and msg.ranges[319] <= 8.000:
        deg320=msg.ranges[319]
        #print("^_________________________________^")
    else:
        #print("deg 320 lost")
        print("dump")
        #print("^_________________________________^")


    #if (((deg0 >= 0.150) and (deg0 <= 8.000)) and ((deg90 >= 0.240) and (deg90 <= 8.000)) and ((deg270 >= 0.240) and (deg270 <= 8.000))):
    #    if (deg0 <= 0.200) and (deg90 <= 0.350) and (deg270 <= 0.350):
    #        send_value = "error" # or back
    #    elif (def0 <= 0.250) and (deg90 <= 0.350) and (deg270 >= 0.350):
    #        send_value = "right"
    #    elif (deg0 <= 0.250) and (deg90 >= 0.350) and (deg270 >= 0.350) and (deg90 < deg270):
    #        send_value = "right"
    #    elif (def0 <= 0.250) and (deg90 >= 0.350) and (deg270 <= 0.350):
    #        send_value = "left"
    #    elif (deg0 <= 0.250) and (deg90 >= 0.350) and (deg270 >= 0.350) and (deg90 > deg270):
    #        send_value = "left"

    #if (deg0 >= 0.250):
    #    send_value = "front"
    #elif (deg0 <= 0.250):
    #    send_value = "error"

    #if ((deg0 >= 0.150) and (deg0 <= 8.000)):
    #    if (deg0 <= 0.350):
    #        send_value = "turn_left"
    #        print("left",deg0)
        #flag = 1

    #    elif (deg0 > 0.350):
            #send_value = "motor_stop"
	    #time.sleep(0.2)
    #        send_value = "front"
	    #time.sleep(0.2)
	    #flag = 0
	#    print("front",deg0)		

#first test code(deg45, deg315)
#    if ((deg0 >= 0.150) and (deg0 <= 8.000)):
#        if (deg0 > 0.250):
#            if (deg45 > 0.350):
#                if (deg315 > 0.350):
#                    send_value = "front"
#                elif (deg315 <= 0.350):
#                    if (deg90 > 0.300) and (deg270 > 0.300) and (deg90 > deg270):
#                        send_value = "left"
#                    elif (deg90 <= 0.300):
#                        send_value = "turn_left"
#            elif (deg45 <= 0.350):
#                if (deg315 > 0.350):
#                    send_value = "right"
#                elif (deg315 <= 0.350):
#                    send_value = "turn_left"
#        elif (deg0 <= 0.250):
#            if (deg90 > deg270):
#                send_value = "left"
#            elif (deg90 < deg270):
#                send_value = "right"
#            elif ((deg45 <= 0.350) and (deg78 <= 1.204) and (deg282 <= 1.204) and (deg315 <= 0.350)):
#                send_value = "turn_left"
        
    # driving when QRcode not recognized
#    if ((deg0 >= 0.150) and (deg0 <= 8.000)):
#        if (deg0 > 0.300):
#            if (deg40 > 0.390):
#                if (deg320 > 0.390):
#                    send_value = "front"
#                elif (deg320 <= 0.390):
#                    if (deg90 > 0.320) and (deg270 > 0.320):
#                        send_value = "left"
#                    elif (deg90 <= 0.320):
#                        send_value = "turn_left"
#            elif (deg40 <= 0.390):
#                if (deg320 > 0.390):
#                    if (deg90 > 0.320) and (deg270 > 0.320):
#                        send_value = "right"
#                    elif (deg270 <= 0.320):
#                        send_value = "turn_left"
#                elif (deg320 <= 0.390):
#                    send_value = "turn_left"
#        elif (deg0 <= 0.300):
#            if (deg40 > 0.390) and (deg320 <= 0.390):
#                send_value = "left"
#            elif (deg40 <= 0.390) and (deg320 > 0.390):
#                send_value = "right"
#            elif (deg40 <= 0.390) and (deg320 <= 0.390):
#                 send_value = "left"

def flag_def(flag_for_package):
    global position
    print("position = " + position)
    if (position == "match_left") or (position == "match"):
        flag_for_package = False
        print("flag changed")
    else:
        print("flag not changed")


def operating(data):
    global deg0, deg40, deg45, deg78, deg90, deg137, deg223, deg270, deg282, deg315, deg320, position, send_value, flag_for_package
    position = data.data
    flag_for_package = True

    # driving when QRcode not recognized
    if position == "not_recognized": # QRcode recognized yet
        if (((deg0 >= 0.150) and (deg0 <= 8.000)) and ((deg90 >= 0.240) and (deg90 <= 8.000)) and ((deg270 >= 0.240) and (deg270 <= 8.000))):
            if (deg0 > 0.300):
                if (deg40 > 0.390):
                    if (deg320 > 0.390):
                        send_value = "front"
                    elif (deg320 <= 0.390):
                        if (deg90 > 0.320) and (deg270 > 0.320):
                            send_value = "left"
                        elif (deg90 <= 0.320):
                            send_value = "turn_left"
                elif (deg40 <= 0.390):
                    if (deg320 > 0.390):
                        if (deg90 > 0.320) and (deg270 > 0.320):
                            send_value = "right"
                        elif (deg270 <= 0.320):
                            send_value = "turn_left"
                    elif (deg320 <= 0.390):
                        send_value = "turn_left"
            elif (deg0 <= 0.300):
                if (deg40 > 0.390) and (deg320 <= 0.390):
                    send_value = "left"
                elif (deg40 <= 0.390) and (deg320 > 0.390):
                    send_value = "right"
                elif (deg40 <= 0.390) and (deg320 <= 0.390):
                    send_value = "left"
        else:
            send_value = "motor_stop"

    elif position == "match":
        print("in the match")
        if (deg0 > 0.550):
            send_value = "front"
        elif (deg0 > 0.200) and (deg0 <= 0.550):
            if (deg40 > 0.500) and (deg40 < 0.600) and (deg320 > 0.500) and (deg320 < 0.600):
                send_value = "front_slow"
            elif (deg40 < 0.500) and (deg320 > 0.600) and ((deg90+deg270) < 2.800):
                send_value = "turn_left"
            elif (deg40 > 0.600) and (deg320 < 0.500) and ((deg90+deg270) < 2.800):
                send_value = "turn_right"
        elif (deg0 <= 0.200):
            send_value = "riftup"
            time.sleep(10)
            send_value = "motor_stop"
            
    elif position == "match_left":
        send_value = "left_real_slow"
        #send_value = "front"
    elif position == "match_right":
        send_value = "right_real_slow"
        #send_value = "front"
    elif position == "miss_matchA_left": # input : packageB, recognize : packageA
        while True:
            send_value = "right_slow"
            position = data.data
            if position == "match_right":
                break
#        send_value = "right_slow"
    elif position == "miss_matchA": # input : packageB, recognize : packageA
        while True:
            send_value = "right_slow"
            position = data.data
            if position == "match_right":
                break
#        send_value = "right_slow"
    elif position == "miss_matchA_right": # input : packageB, recognize : packageA
        while True:
            send_value = "right_slow"
            position = data.data
            if position == "match_right":
                break
#        send_value = "right_slow"
    elif position == "miss_matchB_left": # input : packageA, recognize : packageB
        if position != "match":
            send_value = "left_slow"
    elif position == "miss_matchB": # input : packageA, recognize : packageB
        if position != "match":
            send_value = "left_slow"
    elif position == "miss_matchB_right": # input : packageA, recognize : packageB
        if position != "match":
            send_value = "left_slow"
            #print("===========================data.data = " + data.data + " =================================")
            #position = data.data
            #print("================================in the loop====================================")

#        send_value = "left_slow"

def send_topic():
    global send_value
    rospy.init_node('pub_value', anonymous=True)
    rospy.Subscriber('/scan', LaserScan, callback)
    rospy.Subscriber('package', String, operating)
    pub = rospy.Publisher('driving', String, queue_size=10)
    rate = rospy.Rate(40)
    while not rospy.is_shutdown():
        pub.publish(send_value)
        rate.sleep()

if __name__ == '__main__':
    deg0=0
    deg40=0
    deg45=0
    deg78=0
    deg90=0
    deg137=0
    deg223=0
    deg270=0
    deg282=0
    deg315=0
    deg320=0
    position = "initial value"
    send_value = "initial value"
    flag_for_package = True
    try:
        send_topic()
    except rospy.ROSInterruptException:
        pass
