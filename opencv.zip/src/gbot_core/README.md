# gbot_core
Set of ROS parameter files and scripts to launch Cartographer SLAM

Refer to Youtube video and Medium story for the details:

[![Cartographer on RPi](https://img.youtube.com/vi/qNdcXUEF7KU/0.jpg)](https://www.youtube.com/watch?v=qNdcXUEF7KU)

Text version: https://medium.com/robotics-weekends/2d-mapping-using-google-cartographer-and-rplidar-with-raspberry-pi-a94ce11e44c5


