def operating(data):
    if data.data == "not_recognized" #driving code

    #find guide
    elif data.data == "right"
    elif data.data == "left"
    elif data.data == "center"








rospy.Subscriber("marker", String, operating)
